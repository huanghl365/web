#include "globalvariable.h"

int NetWorkStatus = 0;
