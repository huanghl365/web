#ifndef GLOBALVARIABLE_H
#define GLOBALVARIABLE_H

#include <QString>

#define TEST //test mode
#define CABINETNO "AABBCCDD"

#define OPEN_THREAD 1
#define CLOSE_THREAD 0

#define NETWORK_OFFLINE 0
#define NETWORK_ONLINE  1


extern int NetWorkStatus;

#endif // GLOBALVARIABLE_H
