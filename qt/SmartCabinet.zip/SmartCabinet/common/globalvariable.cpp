#include "globalvariable.h"

int NetWorkStatus = 0;
int userId = 0;
int userRole = 0;
int resetSignal = 0;
QString userName = "";
int SerialPortStatus = -1;
int send_positionNo_G[64] = {0};
bool isQuitLoopRequestAgentiaStatus = false;
bool isClickReturnPB = false;
int groupId = 0;
